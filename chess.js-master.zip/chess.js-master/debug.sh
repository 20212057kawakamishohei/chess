node --inspect-brk node_modules/.bin/jest --runInBand
